
function A = warmUpExercise()

% function [y1,...,yN] = myfun(x1,...,xN)

% above function 'myfun' takes argument (x1,...,xN) and returns y1,...,yN

% Return the 5x5 identity matrix in octave



A = eye(5);

end